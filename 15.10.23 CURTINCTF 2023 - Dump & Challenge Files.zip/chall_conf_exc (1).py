def obfuscate_key(shared_key):
    obfuscated_key_bytes = shared_key.to_bytes((shared_key.bit_length() + 7) // 8, byteorder='big')
    obfuscated_key_bytes_xor = bytes([x ^ 0xFF for x in obfuscated_key_bytes])
    obfuscated_key = int.from_bytes(obfuscated_key_bytes_xor, byteorder='big')
    return obfuscated_key

# Given output
given_output = 7091022811630043496454715564459978004849567585581799855855165734358

# Recover alice_shared_key
obfuscated_alice_key = given_output
alice_shared_key = obfuscate_key(obfuscated_alice_key)

# Recover encrypted_flag
flag_bytes_xor = int.to_bytes(given_output, (given_output.bit_length() + 7) // 8, byteorder='big')
flag_bytes = bytes([x ^ 0xFF for x in flag_bytes_xor])

# Now decode the flag using base64
import base64
flag = base64.b64encode(flag_bytes).decode('utf-8')

print("flag:", flag)
