import base64
from Crypto.Cipher import AES
from Crypto.Protocol.KDF import scrypt
from Crypto.Random import get_random_bytes

p = 233970423115425145524320034830162017933
a = 0
b = 7
n = 233970423115425145498902418297807005944
Gx = 182
Gy = 85518893674295321206118380980485522083
Qx = 7856
Qy = 83120602848774683554512752392153815227

flag = b'REDACTED'
k = (Qx - Gx) * pow(Gy, -1, p) % p
salt = get_random_bytes(16)
key = scrypt(k.to_bytes((k.bit_length() + 7) // 8, 'big'), salt, 32, N=16384, r=8, p=1)
block_size = 16
padding_len = block_size - len(flag) % block_size
flag += bytes([padding_len] * padding_len)
cipher = AES.new(key, AES.MODE_CBC)
ciphertext = cipher.encrypt(flag)
cs = base64.b64encode(cipher.iv + ciphertext + salt)
print("cs:", cs)