from Crypto.Cipher import AES
import base64

def pkcs7_pad(data, block_size):
    padding = block_size - (len(data) % block_size)
    return data + bytes([padding] * padding)

def b_p(data):
    l = [4, 1, 3, 0, 2, 7, 6, 5, 10, 9, 8, 11, 15, 14, 13, 12, 19, 18, 17, 16, 23, 22, 21, 20, 27, 26, 25, 24, 31, 30, 29, 28]
    y = bytearray(32)
    for i, index in enumerate(l):
        if i < len(data):
            y[index] = data[i]
    return bytes(y)

flag = b'REDACTED'
iv = b'\x00' * 16
fp = b_p(flag)
c = AES.new(iv, AES.MODE_ECB)
k = c.encrypt(pkcs7_pad(fp, 32))
cn = AES.new(iv, AES.MODE_CBC, iv)
ctn = cn.encrypt(pkcs7_pad(k, 32))

with open('challenge_file.txt', 'w') as file:
    file.write(base64.b64encode(ctn).decode('utf-8'))