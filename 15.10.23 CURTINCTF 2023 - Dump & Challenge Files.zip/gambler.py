from Crypto.Cipher import AES
from Crypto.Util.number import long_to_bytes, bytes_to_long
import random
import hashlib

flag = b'REDACTED'

def pkcs7_pad(data, block_size):
    padding = block_size - (len(data) % block_size)
    return data + bytes([padding] * padding)

g = 7
x = 11109871761272186707313749920559391609314864049943716089329850308739848274981163174574586779728080951298251641374993669445207041118824097375920261081696413
a = random.randrange(2, x - 1)
B, A = 11, pow(g, a, x)
key = hashlib.md5(long_to_bytes(pow(B, a, x))).digest()
cipher = AES.new(key, AES.MODE_ECB)
d_p = pkcs7_pad(flag, AES.block_size)
enc = cipher.encrypt(d_p)
print("Encrypted flag: ", bytes_to_long(enc))